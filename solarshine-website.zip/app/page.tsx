import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Phone, Sparkles, CalendarCheck, MessageCircle } from "lucide-react";
import { motion } from "framer-motion";

export default function SolarShineWebsite() {
  return (
    <main className="p-4 md:p-8 max-w-4xl mx-auto space-y-6">
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center"
      >
        <h1 className="text-4xl font-bold text-yellow-500">SolarShine Services</h1>
        <p className="text-lg mt-2 text-gray-600">Dirt Off, Watts Up!</p>
      </motion.header>

      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="grid grid-cols-1 md:grid-cols-3 gap-4"
      >
        <Card className="rounded-2xl shadow-md">
          <CardContent className="p-4 space-y-2 text-center">
            <Sparkles className="mx-auto text-yellow-500" size={32} />
            <h2 className="font-semibold text-lg">One-Time Cleaning</h2>
            <p>R80 per panel or R500 for a small home system.</p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl shadow-md">
          <CardContent className="p-4 space-y-2 text-center">
            <CalendarCheck className="mx-auto text-yellow-500" size={32} />
            <h2 className="font-semibold text-lg">Monthly Plans</h2>
            <p>Regular maintenance with 10% discount on packages.</p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl shadow-md">
          <CardContent className="p-4 space-y-2 text-center">
            <Phone className="mx-auto text-yellow-500" size={32} />
            <h2 className="font-semibold text-lg">Get a Quote</h2>
            <p>WhatsApp or call us today for a free consultation.</p>
          </CardContent>
        </Card>
      </motion.section>

      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.4 }}
        className="bg-yellow-50 rounded-2xl p-6 shadow-md"
      >
        <h2 className="text-xl font-semibold text-yellow-600 mb-2">Why Choose Us?</h2>
        <ul className="list-disc list-inside space-y-1 text-gray-700">
          <li>Improve solar efficiency by up to 30%</li>
          <li>Eco-friendly and safe cleaning methods</li>
          <li>Experienced and trained technicians</li>
          <li>Fast response time in Johannesburg & nearby areas</li>
        </ul>
      </motion.section>

      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.5 }}
        className="bg-white rounded-2xl p-6 shadow-md space-y-4"
      >
        <h2 className="text-xl font-semibold text-yellow-600">Customer Testimonials</h2>
        <div className="space-y-3 text-sm text-gray-700">
          <blockquote className="border-l-4 border-yellow-400 pl-4 italic">
            “My solar system gained back its full output after just one clean. Highly recommend SolarShine!”<br />
            <span className="text-yellow-600 font-medium">– Lerato M., Randburg</span>
          </blockquote>
          <blockquote className="border-l-4 border-yellow-400 pl-4 italic">
            “Friendly, professional and fast! Their monthly plan saved me a lot over time.”<br />
            <span className="text-yellow-600 font-medium">– Thabo D., Midrand</span>
          </blockquote>
        </div>
      </motion.section>

      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.6 }}
        className="bg-yellow-100 rounded-2xl p-6 shadow-md"
      >
        <h2 className="text-xl font-semibold text-yellow-700 mb-4">Contact Us</h2>
        <form className="space-y-4">
          <input type="text" placeholder="Your Name" className="w-full p-2 rounded-md border" required />
          <input type="email" placeholder="Email Address" className="w-full p-2 rounded-md border" required />
          <textarea placeholder="Your Message" className="w-full p-2 rounded-md border" rows={4} required />
          <Button className="w-full bg-yellow-500 hover:bg-yellow-600">Send Message</Button>
        </form>
        <p className="text-center text-sm mt-4">
          Or reach us on WhatsApp: <a href="https://wa.me/27600000000" className="text-yellow-700 font-medium">+27 60 000 0000</a>
        </p>
      </motion.section>

      <motion.footer
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6, delay: 0.7 }}
        className="text-center text-sm text-gray-500 pt-6"
      >
        © 2025 SolarShine Services. All rights reserved.
      </motion.footer>
    </main>
  );
}